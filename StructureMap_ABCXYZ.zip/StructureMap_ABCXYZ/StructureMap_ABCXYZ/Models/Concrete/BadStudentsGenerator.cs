﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StructureMap_ABCXYZ.Models.Interface;
namespace StructureMap_ABCXYZ.Models.Concrete
{
    public class BadStudentsGenerator :IStudentsGenerator
    {
        public List<Student> GenerateStudents(int NoOfStudents)
        {
            List<Student> students = new List<Student>();
            Random rd = new Random();
            for (int i = 1; i <= NoOfStudents; i++)
            {
                Student student = new Student();
                student.ID = i;
                student.Name = "Name No." + i.ToString();

                // This generates integer scores between 0 - 40
                student.Score = Convert.ToInt16(40 * rd.NextDouble());
                student.Activity = "Gambling - Bad";

                students.Add(student);
            }

            return students;
        }
    }
}