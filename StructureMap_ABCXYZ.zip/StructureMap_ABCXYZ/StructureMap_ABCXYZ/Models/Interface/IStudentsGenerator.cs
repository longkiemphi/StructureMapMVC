﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureMap_ABCXYZ.Models.Interface
{
  public  interface IStudentsGenerator
    {
        List<Student> GenerateStudents(int NoOfStudents);
    }
}
