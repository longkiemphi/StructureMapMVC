﻿using System.Web;
using System.Web.Mvc;

namespace StructureMap_ABCXYZ
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
