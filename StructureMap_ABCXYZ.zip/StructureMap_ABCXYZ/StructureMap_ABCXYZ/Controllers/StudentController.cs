﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StructureMap_ABCXYZ.Models.Concrete;
using StructureMap_ABCXYZ.Models.Interface;
namespace StructureMap_ABCXYZ.Controllers
{
    public class StudentController : Controller
    {
        private IStudentsGenerator studentGenerator;

        public StudentController(IStudentsGenerator studentGenerator)
        {
            this.studentGenerator = studentGenerator;
        }

        [HttpGet]
        public ActionResult Index() { return View(); }

        [HttpGet]
        public ActionResult LoadStudents()
        {
            //studentGenerator
            //    = ObjectFactory.GetInstance<IStudentsGenerator>();
            return View(studentGenerator.GenerateStudents(10));
        }
    }
}