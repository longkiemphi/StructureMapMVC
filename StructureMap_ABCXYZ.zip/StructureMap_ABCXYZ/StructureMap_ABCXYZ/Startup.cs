﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(StructureMap_ABCXYZ.Startup))]
namespace StructureMap_ABCXYZ
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
